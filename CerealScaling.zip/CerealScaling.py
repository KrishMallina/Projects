# -*- coding: utf-8 -*-
"""
Created on Tue Oct 19 11:57:43 2021

@author: 848223
"""

import numpy as np
import matplotlib.pyplot as plt

def readTrainData():
    fileName = "Cereal_Train.csv"
    raw_data = open(fileName, 'rt')
    
    data = np.loadtxt(raw_data, usecols = np.arange(2, 15), skiprows = 1, delimiter = ",")
    return data

def readTestData():
    fileName = "Cereal_Test.csv"
    raw_data = open(fileName, 'rt')
    
    data = np.loadtxt(raw_data, usecols = np.arange(2, 15), skiprows = 1, delimiter = ",")
    return data

def costFunc(x, weights, y):
    predicted = (np.dot(x, weights) - y) ** 2
    sum_squared_error = np.sum(predicted) / (2 * len(y))
    return sum_squared_error

def gradDesc(x, weights, y):
    predicted = np.dot(x, weights)
    
    diff = predicted - y
    
    x = x.transpose()
    
    gradients = np.dot(x, diff)
    gradients = gradients / len(y)
    
    return gradients

trainData = readTrainData()
testData = readTestData()

#mean normalization
x = trainData[:, 0:(len(trainData[0]) - 1)]
avg = np.mean(x, axis = 0)
denominator = np.amax(x, axis = 0) - np.amin(x, axis = 0)

x = (x - avg) / denominator
x = np.append(np.ones((len(x), 1)), x, axis = 1)

y = trainData[:, (len(trainData[0]) - 1)]
y = y.reshape((len(y), 1))

weights = np.ones((len(x[0]), 1))

tolerance = 0.001
LR = 1.985
costArray = []

vectNorm = 1
iterations = 0

while (vectNorm > tolerance):
    cost = costFunc(x, weights, y)
    costArray.append(cost)
    
    gradients = gradDesc(x, weights, y)
    
    #update weights 
    weights = weights - (LR * gradients)
    iterations += 1
    vectNorm = np.linalg.norm(gradients)

# plot cost
fig2 = plt.figure()
ax2 = fig2.add_axes([0.1, 0.1, 0.8, 0.8])
ax2.plot(range(iterations), costArray, color='blue')
ax2.set(title = 'Cost vs. Iterations', xLabel = 'iterations', yLabel = 'cost')

#test the weights
testX = testData[:, 0:(len(testData[0]) - 1)]

testY = testData[:, (len(testData[0]) - 1)]
testY = testY.reshape((len(testY), 1))

testX = (testX - avg) / denominator
testX = np.append(np.ones((len(testX), 1)), testX, axis = 1)

testCost = costFunc(testX, weights, testY)
print(testCost)